download the GloVe file here.

download KBP/NYT/TACRED data in corresponding folders.
