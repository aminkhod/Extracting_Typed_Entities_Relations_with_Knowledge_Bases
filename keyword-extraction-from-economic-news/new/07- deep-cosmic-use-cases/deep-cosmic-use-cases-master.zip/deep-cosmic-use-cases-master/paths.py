word_embeddings_folder = "E:\\Research\\Datasets\\word_embeddings\\"
input_folder = "./input/"
output_folder = "./output/"