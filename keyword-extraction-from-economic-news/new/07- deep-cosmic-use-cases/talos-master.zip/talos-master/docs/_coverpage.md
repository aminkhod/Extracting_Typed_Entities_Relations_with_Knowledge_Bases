![logo](_media/talos_logo_bg.png)

## v1.0

> Hyperparameter Experiments with Tensorflow, PyTorch and Keras

[GitHub](https://github.com/autonomio/talos/)
[Getting Started](https://autonomio.github.io/talos/#/README?id=quick-start)

![color](#f0f0f0)
