# TensorFlow

Talos versions 1.0 and higher support TensorFlow 2.0 and higher. If you want to use older version of TensorFlow, Talos versions until 0.6.x support TensorFlow 1.4. 

# PyTorch

Only Talos versions 1.0 and higher have full support for PyTorch.

For instrucions on how to use Talos with PyTorch, see [this example](Examples_PyTorch).


# Legacy Keras 

Talos versions 0.6.x and lower support the multi-backend Keras. 