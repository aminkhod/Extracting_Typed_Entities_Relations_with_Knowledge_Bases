# 💬 How to get Support

| I want to...                     | Go to...                                                  |
| -------------------------------- | ---------------------------------------------------------- |
| **...troubleshoot**           | [Docs] · [Wiki] · [GitHub Issue Tracker]                   |
| **...report a bug**           | [GitHub Issue Tracker]                                     |
| **...suggest a new feature**  | [GitHub Issue Tracker]                                     |
| **...get support**            | [Stack Overflow] · [Spectrum Chat]                         |
| **...have a discussion**      | [Spectrum Chat]                                            |

[github issue tracker]: https://github.com/automio/talos/issues
[docs]: https://autonomio.github.io/docs_talos
[wiki]: https://github.com/autonomio/talos/wiki
[stack overflow]: https://stackoverflow.com/questions/tagged/talos
[spectrum chat]: https://spectrum.chat/talos
