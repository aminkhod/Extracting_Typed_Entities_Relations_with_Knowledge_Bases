import tensorflow
print('TensorFlow %s' % tensorflow.__version__)

import talos
print('Talos %s' % talos.__version__)

import sys
print('Python %s' % sys.version.split()[0])