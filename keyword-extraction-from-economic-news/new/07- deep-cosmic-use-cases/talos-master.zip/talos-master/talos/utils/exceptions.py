class TalosReturnError(Exception):
    pass


class TalosParamsError(Exception):
    pass


class TalosTypeError(Exception):
    pass


class TalosModelError(Exception):
    pass


class TalosDataError(Exception):
    pass
