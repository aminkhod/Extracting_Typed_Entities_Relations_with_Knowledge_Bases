# analysis
processing tweets and analysing

For pipeline of tweets - process with Doc2Vec and then use a classifier on embeddings (e.g. Log Regression of SciKit Learn). Some evaluation outputs also.
