#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Copyright 2019 Information Retrieval Lab
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import argparse
import logging
import multiprocessing
import os
import sys
import time

from embeddings import Embeddings
from ratings_matrix import QRel, TabDataSet
from recommender import WSRRec

WORKERS = multiprocessing.cpu_count()

K = 100
MAX_ITEMS = 100


def do_single_run(output_dir, k, max_items, embeddings_file, ratings_train,
                  test_items, item_based, users=None, workers=1):
    logger = logging.getLogger(multiprocessing.current_process().name)

    sim_sufix = 'cosine'

    if os.path.isfile(embeddings_file):
        logger.info('Processing: %s', embeddings_file)
    else:
        logger.warning('Could not find %s. Skipping', embeddings_file)
        return

    file_without_ext = os.path.splitext(os.path.basename(embeddings_file))[0]
    output_file = os.path.join(output_dir,
                               'run-{0}NN-{1}-{2}.txt'.format(k, sim_sufix,
                                                              file_without_ext))

    if os.path.isfile(output_file):
        logger.info('Output file exists, skipping: %s', output_file)
        return

    embeddings = Embeddings(embeddings_file)
    embeddings.optimize_knn_search(k)

    run = WSRRec(item_based, test_items, embeddings, ratings_train, users)

    try:
        run.calculate_rankings_to_run_file(k, output_file, max_items, workers)
    except KeyboardInterrupt:
        logging.warning('Interruption received, deleting partially done run '
                        'file')
        os.remove(output_file)
        return

    logger.info('Done processing: %s', embeddings_file)
    logger.info('Wrote run file: %s', output_file)


def build_arg_parser():
    argparser = argparse.ArgumentParser(
        description="""Generate a run file with rankings for each user. The
        generated file is in a format recognized by the trec_eval tool.""",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)

    argparser.add_argument('-k', type=int, default=K, help="""Number of
                           neighbors to consider when calculating the score of
                           an item.""")
    argparser.add_argument('-n', '--max-items', type=int, default=100,
                           help="""Max number of items to include in the
                           ranking list for an user. 0 to include all items.
                           """)
    argparser.add_argument('-u', '--users', help=argparse.SUPPRESS, type=int,
                           default=None)
    argparser.add_argument('-o', '--output-dir', help="""Directory where to
                           write the resulting rankings.""", required=True)

    argparser.add_argument('-i', '--input-file', help='Embeddings file',
                           required=True)

    argparser.add_argument('--train-datapath', help="""File with ratings used
                           during training""", required=True)
    argparser.add_argument('--qrels', help="""File with relevance judgements,
                           i.e. the test dataset""", required=True)

    item_or_user_group = argparser.add_mutually_exclusive_group()
    item_or_user_group.add_argument('--item-based', dest='item_based',
                                    action='store_true', help="""Item based
                                    recommender""")
    item_or_user_group.add_argument('--user-based', dest='item_based',
                                    action='store_false', help="""User based
                                    recommender""")

    argparser.add_argument('-w', '--workers', help="""How many workers to use
                           in the worker pool.""", type=int, default=WORKERS)

    return argparser


def main(argv):
    argparser = build_arg_parser()
    args = argparser.parse_args(argv[1:])

    ratings_train = TabDataSet(args.train_datapath)
    ratings_test = QRel(args.qrels)
    test_items = ratings_train.items_set() & ratings_test.items_set()

    if args.users is None:
        users = args.users
    else:
        users = set(range(1, args.users + 1))

    if not os.path.isdir(args.output_dir):
        print('{0} is not a directory.'.format(args.output_dir))
        sys.exit(-1)

    logging.basicConfig(level=logging.INFO, stream=sys.stdout)
    logger = logging.getLogger()
    start = time.time()

    do_single_run(args.output_dir, args.k, args.max_items, args.input_file,
                  ratings_train, test_items, args.item_based, users,
                  args.workers)

    duration = int(time.time() - start)

    seconds = duration % 60
    minutes = duration // 60

    if minutes >= 60:
        template = 'Processing done in {0} hours, {1} minutes, {2} seconds'
        log_msg = template.format(minutes // 60, minutes % 60, seconds)
    else:
        template = 'Processing done in {0} minutes, {1} seconds'
        log_msg = template.format(minutes, seconds)
    logger.info(log_msg)


if __name__ == '__main__':
    main(sys.argv)
