prefs2vec
=========

Code to create embeddings and to generate recommendations as described in paper
"Collaborative Filtering Embeddings for Memory-based Recommender Systems".

Dependencies
------------

The code has the following python dependencies:

+ numpy
+ gensim

Usage
-----

The code is divided in 2 scripts, one to build the embeddings and another to
use these embeddings to generate recommendations.

The dataset file should be in a CSV format with columns for `userId`, `movieId` and
`rating`, optionally followed by a `timestamp`. Fields can be separated by
commas or whitespaces.

The test set file should be in the standard qrel format of the `trec_eval` tool.
The fields in this file, with 0 being an unused field, are:

```
userId  0  itemId  rating
```

The file with the recommendations is in a standard result format of the tool
`trec_eval`. The fields of this file, where Q0 and Exp are unused fields, are:

```
userId  Q0  itemId  rank  score  Exp
```

The results can be evaluated using the [trec\_eval][1] or the [rec\_eval][2] tools.

[1]: https://github.com/usnistgov/trec_eval
[2]: https://github.com/dvalcarce/rec_eval

Usage of the script to build embeddings is:


```
usage: build_w2v_embeddings.py [-h] -d DIM [-w WIN] [-c COUNT] [-i ITERS]
                               [-m {cbow,sg}] [-t {ns,hs}] [-s SAMPLES] -o
                               OUTPUT_DIR [--function {bin,id}]
                               [--shuffle {0,1,2}] --datapath DATAPATH
                               [--save-out-embs SAVE_OUT_EMBS]
                               [--workers WORKERS]
                               [--item-based | --user-based]

Generate embeddings.

optional arguments:
  -h, --help            show this help message and exit
  -d DIM, --dimension DIM
                        Number of dimensions. (default: None)
  -w WIN, --window-size WIN
                        Window size. (default: 10)
  -c COUNT, --min_count COUNT
                        Minimun number of ratings needed for an item to be
                        included in the vocabulary. (default: 1)
  -i ITERS, --iters ITERS
                        Number of iterations to train the model. (default: 10)
  -m {cbow,sg}, --model {cbow,sg}
                        Which word2vec model to use to build the embeddings
                        (default: cbow)
  -t {ns,hs}, --training-method {ns,hs}
                        Which method to use to train the word2vec model
                        (default: hs)
  -s SAMPLES, --negative-samples SAMPLES
                        Amount of negative samples to take. This parameter is
                        mandatory for negative sampling and ignored for
                        hierarchical softmax (default: None)
  -o OUTPUT_DIR, --output-dir OUTPUT_DIR
                        Where to write the files with the embeddings generated
                        by the models. (default: None)
  --function {bin,id}   Which function to use when repeating items based on
                        their ratings (default: id)
  --shuffle {0,1,2}     Whether to shuffle the items or not before feeding
                        them to the word2vec model. 0 for not shuffle, 1 for
                        shuffle every training iteration, 2 for shuffle just
                        once before training. (default: 1)
  --datapath DATAPATH   Use this file to load ratings data to build the
                        embeddings (default: None)
  --save-out-embs SAVE_OUT_EMBS
                        Save output embeddings. Only has effect if negative
                        sampling is used. (default: False)
  --workers WORKERS     How many workers to use to build the word2vec models
                        (default: 16)
  --item-based          Build item based embeddings (default: True)
  --user-based          Build user based embeddings (default: False)
```

Example usage of this script, building user based embeddings of dimension 300,
window 50, training a CBOW model using negative sampling of 10 samples for 300
iterations:

```
$ ./build_w2v_embeddings.py -d 300 -w 50 -m cbow -t ns -s 10 --function id --shuffle 1 --user-based -i 300 --datapath ml-20m/base/u1.base -o .
```

Usage of the script to generate the recommendations is:

```
usage: generate_recommendations.py [-h] [-k K] [-n MAX_ITEMS] -o OUTPUT_DIR -i
                                   INPUT_FILE --train-datapath TRAIN_DATAPATH
                                   --qrels QRELS [--item-based | --user-based]
                                   [-w WORKERS]

Generate a run file with rankings for each user. The generated file is in a
format recognized by the trec_eval tool.

optional arguments:
  -h, --help            show this help message and exit
  -k K                  Number of neighbors to consider when calculating the
                        score of an item. (default: 100)
  -n MAX_ITEMS, --max-items MAX_ITEMS
                        Max number of items to include in the ranking list for
                        an user. 0 to include all items. (default: 100)
  -o OUTPUT_DIR, --output-dir OUTPUT_DIR
                        Directory where to write the resulting rankings.
                        (default: None)
  -i INPUT_FILE, --input-file INPUT_FILE
                        Embeddings file (default: None)
  --train-datapath TRAIN_DATAPATH
                        File with ratings used during training (default: None)
  --qrels QRELS         File with relevance judgements, i.e. the test dataset
                        (default: None)
  --item-based          Item based recommender (default: False)
  --user-based          User based recommender (default: True)
  -w WORKERS, --workers WORKERS
                        How many workers to use in the worker pool. (default:
                        16)
```

To generate recommendation from the previously generated embeddings, with k=100:

```
$ ./generate_recommendations.py -k 100 -i UB-300-cbow-ns10-w50-c1-i300-id-fold1.embeddings --train-datapath ml-20m/base/u1.base --qrels ml-20m/qrels/u1.qrel --user-based -o .
```

These recommendations can be evaluated with the `rec_eval` tool:

```
$ rec_eval -c -m recsys -l 4 ml-20m/qrels/u1.qrel run-100NN-cosine-UB-300-cbow-ns10-w50-c1-i300-id-fold1.txt
```

